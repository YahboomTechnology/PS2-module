#include "ti_msp_dl_config.h"
#include "delay.h"
#include "usart.h"
#include "pstwo.h"


int main(void)
{
	extern int AnalogFLAG;

	USART_Init();
 	while(1)
	{		
		Get_PS2data();
		if(!PS2_RedLight())//切换为模拟量输入模式时，开始控制小车	When switching to analog input mode, start controlling the car
		{
			PS2_CarControl();
		} 
		delay_ms(2);
	}	 
}



