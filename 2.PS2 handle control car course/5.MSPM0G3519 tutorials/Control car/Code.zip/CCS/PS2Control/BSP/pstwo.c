#include "pstwo.h"
#include "usart.h"

u16 Handkey;
u8 Comd[2]={0x01,0x42};	//开始命令。请求数据	Start command. Request data
u8 Data[9]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; //数据存储数组	Data storage array
int PS2_LX,PS2_LY,PS2_RX,PS2_RY,PS2_KEY;

u16 MASK[]={
	PSB_SELECT,
	PSB_L3,
	PSB_R3 ,
	PSB_START,
	PSB_PAD_UP,
	PSB_PAD_RIGHT,
	PSB_PAD_DOWN,
	PSB_PAD_LEFT,
	PSB_L2,
	PSB_R2,
	PSB_L1,
	PSB_R1 ,
	PSB_GREEN,
	PSB_RED,
	PSB_BLUE,
	PSB_PINK
};	//按键值与按键名	Key value and key name

//向手柄发送命令	Sending commands to the controller
void PS2_Cmd(u8 CMD)
{
	volatile u16 ref=0x01;
	Data[1] = 0;
	for(ref=0x01;ref<0x0100;ref<<=1)
	{
		if(ref&CMD)
		{
			DO_H; //输出一位控制位	Output a control bit
		}
		else DO_L;

		CLK_H; //时钟拉高	Clock pull high
		delay_us(11);
		CLK_L;
		delay_us(11);
		CLK_H;
		if(DI)
		{
			Data[1] = ref|Data[1];
		}
	}
//	printf("Receive Data:%#X\r\n",Data[1]);
}

//判断是否为红灯模式	Judge whether it is red light mode
//返回值；0，红灯模式	Return value: 0, red light mode
//其他，其他模式		Others, other modes
u8 PS2_RedLight(void)
{
	CS_L;
	PS2_Cmd(Comd[0]);  //开始命令	Start Command
	PS2_Cmd(Comd[1]);  //请求数据	Request data
	CS_H;
	if( Data[1] == 0X73)   return 0 ;
	else return 1;

}
//读取手柄数据	Read controller data
void PS2_ReadData(void)
{
	volatile u8 byte=0;
	volatile u16 ref=0x01;

	CS_L;

	PS2_Cmd(Comd[0]);  //开始命令	Start Command
	PS2_Cmd(Comd[1]);  //请求数据	Request data

	for(byte=2;byte<9;byte++) //开始接受数据	Start receiving data
	{
		for(ref=0x01;ref<0x100;ref<<=1)
		{
			CLK_H;
			CLK_L;
			delay_us(11);
			CLK_H;
		      if(DI)
		      Data[byte] = ref|Data[byte];
		}
        delay_us(11);
	}
	CS_H;	
}

//对读出来的PS2的数据进行处理      只处理了按键部分         默认数据是红灯模式  只有一个按键按下时
//Process the PS2 data read out. Only the key part is processed. The default data is red light mode. When only one key is pressed
//按下为0， 未按下为1	Pressed is 0, not pressed is 1
u8 PS2_DataKey()
{
	u8 index;

	PS2_ClearData();
	PS2_ReadData();

	Handkey=(Data[4]<<8)|Data[3];//这是16个按键  按下为0， 未按下为1	These are 16 keys. If pressed, it is 0. If not pressed, it is 1.
	for(index=0;index<16;index++)
	{	    
		if((Handkey&(1<<(MASK[index]-1)))==0)
		return index+1;
	}
	return 0; //没有任何按键按下	No keys pressed
}

//得到一个摇杆的模拟量	 范围0~256	Get the analog value of a joystick, range 0~256
u8 PS2_AnologData(u8 button)
{
	return Data[button];
}

//清除数据缓冲区	Clear the data buffer
void PS2_ClearData()
{
	u8 a;
	for(a=0;a<9;a++)
		Data[a]=0x00;
}

void Get_PS2data(void)
{
	PS2_LX=PS2_AnologData(PSS_LX);
	PS2_LY=PS2_AnologData(PSS_LY);
	PS2_RX=PS2_AnologData(PSS_RX);
	PS2_RY=PS2_AnologData(PSS_RY);
	PS2_KEY=PS2_DataKey();
	
//	printf("PS2_LX=%d    ",PS2_LX);
//	printf("PS2_LY=%d    ",PS2_LY);
//	printf("PS2_RX=%d    ",PS2_RX);
//	printf("PS2_RY=%d    ",PS2_RY);
//	printf("PS2_KEY=%d    \r\n",PS2_KEY);
	
}

void PS2_CarControl(void)
{
	//----摇杆直向控制---//
	//----Joystick vertical control---//
	if(PS2_LX == 128 && PS2_LY == 127)
	{
		Motion_Set_Pwm(0,0,0,0);
	}

	if(PS2_LY>=0&&PS2_LY<70)//直走	Go straight
	{
		Motion_Set_Pwm(200,200,200,200);
	}
	
	if(PS2_LY<=255 && PS2_LY>200 &&PS2_LX == 128)//后退	Back
	{
		Motion_Set_Pwm(-200,-200,-200,-200);
	}
	
	if(PS2_LX>=0&&PS2_LX<70)//左旋	Rotate Left
	{
		Motion_Set_Pwm(-400,700,-400,700);
	}
	
	if(PS2_LX<=255 && PS2_LX>200 && PS2_LY == 127)//右旋	Rotate Right
	{
		Motion_Set_Pwm(700,-400,700,-400);
	}
	
	//----摇杆斜向控制---//
	//----Joystick tilt control---//
	if(PS2_LX >= 0&&PS2_LX <= 90 && PS2_LY >= 0&&PS2_LY <= 70)//左前旋转	Left front rotation
	{
		Motion_Set_Pwm(0,500,0,500);
	}
	if(PS2_LX >= 165&&PS2_LX <= 255 && PS2_LY >= 0&&PS2_LY <= 70)//右前旋转	Right front rotation
	{
		Motion_Set_Pwm(500,0,500,0);
	}
	if(PS2_LX >= 0&&PS2_LX <= 90 && PS2_LY >= 165&&PS2_LY <= 255)//左后旋转	Left rear rotation
	{
		Motion_Set_Pwm(0,-500,0,-500);
	}
	if(PS2_LX >= 165&&PS2_LX <= 255 && PS2_LY >= 165&&PS2_LY <= 255)//右后旋转	Right rear rotation
	{
		Motion_Set_Pwm(-500,0,-500,0);
	}
	
	//---方向按键控制---//
	//---Direction button control---//
	switch(PS2_KEY){
		case KEY_FORWARD:
			Motion_Set_Pwm(200,200,200,200);
		break;
		
		case KEY_BACK:
			Motion_Set_Pwm(-200,-200,-200,-200);
		break;
		
		case KEY_SPINRIGHT:
			Motion_Set_Pwm(700,-400,700,-400);
		break;
		
		case KEY_SPINLEFT:
			Motion_Set_Pwm(-400,700,-400,700);
		break;
		
		defalut:
		break;
	}
}