################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../APP/app_motor.c 

C_DEPS += \
./APP/app_motor.d 

OBJS += \
./APP/app_motor.o 

OBJS__QUOTED += \
"APP\app_motor.o" 

C_DEPS__QUOTED += \
"APP\app_motor.d" 

C_SRCS__QUOTED += \
"../APP/app_motor.c" 


