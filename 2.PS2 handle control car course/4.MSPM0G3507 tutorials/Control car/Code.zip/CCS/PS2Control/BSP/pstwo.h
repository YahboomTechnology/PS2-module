#ifndef __PSTWO_H
#define __PSTWO_H
#include "ti_msp_dl_config.h"
#include "app_motion.h"
#include "delay.h"
#include "stdio.h"

#define DI   DL_GPIO_readPins(GPIO_PORT, GPIO_MISO_PIN)

#define DO_H DL_GPIO_setPins(GPIO_PORT, GPIO_MOSI_PIN);  //����λ�� Command bit high
#define DO_L DL_GPIO_clearPins(GPIO_PORT, GPIO_MOSI_PIN);//����λ�� Command bit low

#define CS_H DL_GPIO_setPins(GPIO_PORT, GPIO_CS_PIN);   //CS����    CS pull high
#define CS_L DL_GPIO_clearPins(GPIO_PORT, GPIO_CS_PIN); //CS����    CS pull low

#define CLK_H DL_GPIO_setPins(GPIO_PORT, GPIO_CLK_PIN);  //ʱ������ Clock high
#define CLK_L DL_GPIO_clearPins(GPIO_PORT, GPIO_CLK_PIN);//ʱ������ Clock low

#define u8 uint8_t
#define u16 uint16_t
#define u32 uint32_t

//These are our button constants
#define PSB_SELECT      1
#define PSB_L3          2
#define PSB_R3          3
#define PSB_START       4
#define PSB_PAD_UP      5
#define PSB_PAD_RIGHT   6
#define PSB_PAD_DOWN    7
#define PSB_PAD_LEFT    8
#define PSB_L2          9
#define PSB_R2          10
#define PSB_L1          11
#define PSB_R1          12
#define PSB_GREEN       13
#define PSB_RED         14
#define PSB_BLUE        15
#define PSB_PINK        16
#define PSB_TRIANGLE    13
#define PSB_CIRCLE      14
#define PSB_CROSS       15
#define PSB_SQUARE      26

//#define WHAMMY_BAR		8

//These are stick values
#define PSS_RX 5      //��ҡ��X������ Right joystick X-axis data
#define PSS_RY 6
#define PSS_LX 7
#define PSS_LY 8

#define KEY_FORWARD 5  //���򰴼�   Direction buttons
#define KEY_SPINRIGHT 6
#define KEY_BACK 7
#define KEY_SPINLEFT 8

extern u8 Data[9];
extern u16 MASK[16];
extern u16 Handkey;

u8 PS2_RedLight(void);//�ж��Ƿ�Ϊ���ģʽ  Determine whether it is red light mode
void PS2_ReadData(void);
void PS2_Cmd(u8 CMD);		  //
u8 PS2_DataKey(void);		  //��ֵ��ȡ    Key-value reading
u8 PS2_AnologData(u8 button); //�õ�һ��ҡ�˵�ģ����    Get the analog value of a joystick
void PS2_ClearData(void);	  //������ݻ�����  Clear the data buffer
void Get_PS2data(void);
void PS2_CarControl(void);

#endif





