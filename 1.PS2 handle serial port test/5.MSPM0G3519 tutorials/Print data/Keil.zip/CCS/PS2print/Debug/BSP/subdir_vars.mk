################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/delay.c \
../BSP/pstwo.c \
../BSP/usart.c 

C_DEPS += \
./BSP/delay.d \
./BSP/pstwo.d \
./BSP/usart.d 

OBJS += \
./BSP/delay.o \
./BSP/pstwo.o \
./BSP/usart.o 

OBJS__QUOTED += \
"BSP\delay.o" \
"BSP\pstwo.o" \
"BSP\usart.o" 

C_DEPS__QUOTED += \
"BSP\delay.d" \
"BSP\pstwo.d" \
"BSP\usart.d" 

C_SRCS__QUOTED += \
"../BSP/delay.c" \
"../BSP/pstwo.c" \
"../BSP/usart.c" 


