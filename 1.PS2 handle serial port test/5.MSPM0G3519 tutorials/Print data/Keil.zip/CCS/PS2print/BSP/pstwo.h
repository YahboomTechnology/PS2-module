#ifndef __PSTWO_H
#define __PSTWO_H
#include "ti_msp_dl_config.h"
#include "delay.h"
#include "stdio.h"

#define DI   DL_GPIO_readPins(GPIO_PORT, GPIO_MISO_PIN)

#define DO_H DL_GPIO_setPins(GPIO_PORT, GPIO_MOSI_PIN);  //命令位高 Command bit high
#define DO_L DL_GPIO_clearPins(GPIO_PORT, GPIO_MOSI_PIN);//命令位低 Command bit low

#define CS_H DL_GPIO_setPins(GPIO_PORT, GPIO_CS_PIN);   //CS拉高    CS pull high
#define CS_L DL_GPIO_clearPins(GPIO_PORT, GPIO_CS_PIN); //CS拉低    CS pull low

#define CLK_H DL_GPIO_setPins(GPIO_PORT, GPIO_CLK_PIN);  //时钟拉高 Clock high
#define CLK_L DL_GPIO_clearPins(GPIO_PORT, GPIO_CLK_PIN);//时钟拉低 Clock low

#define u8 uint8_t
#define u16 uint16_t
#define u32 uint32_t

//These are our button constants
#define PSB_SELECT      1
#define PSB_L3          2
#define PSB_R3          3
#define PSB_START       4
#define PSB_PAD_UP      5
#define PSB_PAD_RIGHT   6
#define PSB_PAD_DOWN    7
#define PSB_PAD_LEFT    8
#define PSB_L2          9
#define PSB_R2          10
#define PSB_L1          11
#define PSB_R1          12
#define PSB_GREEN       13
#define PSB_RED         14
#define PSB_BLUE        15
#define PSB_PINK        16
#define PSB_TRIANGLE    13
#define PSB_CIRCLE      14
#define PSB_CROSS       15
#define PSB_SQUARE      26

//#define WHAMMY_BAR		8

//These are stick values
#define PSS_RX 5      //右摇杆X轴数据 Right joystick X-axis data
#define PSS_RY 6
#define PSS_LX 7
#define PSS_LY 8

extern u8 Data[9];
extern u16 MASK[16];
extern u16 Handkey;

u8 PS2_RedLight(void);//判断是否为红灯模式  Determine whether it is red light mode
void PS2_ReadData(void);
void PS2_Cmd(u8 CMD);
u8 PS2_DataKey(void);		  //键值读取    Key-value reading
u8 PS2_AnologData(u8 button); //得到一个摇杆的模拟量    Get the analog value of a joystick
void PS2_ClearData(void);	  //清除数据缓冲区  Clear the data buffer

#endif





