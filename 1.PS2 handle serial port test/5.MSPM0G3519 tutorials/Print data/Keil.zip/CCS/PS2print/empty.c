#include "ti_msp_dl_config.h"
#include "delay.h"
#include "usart.h"
#include "pstwo.h"


int main(void)
{
	int PS2_LX,PS2_LY,PS2_RX,PS2_RY,PS2_KEY;
	USART_Init();
 	while(1)
	{		
		PS2_LX=PS2_AnologData(PSS_LX);
		PS2_LY=PS2_AnologData(PSS_LY);
		PS2_RX=PS2_AnologData(PSS_RX);
		PS2_RY=PS2_AnologData(PSS_RY);
		PS2_KEY=PS2_DataKey();
		
		printf("PS2_LX=%d    ",PS2_LX);
		printf("PS2_LY=%d    ",PS2_LY);
		printf("PS2_RX=%d    ",PS2_RX);
		printf("PS2_RY=%d    ",PS2_RY);
		printf("PS2_KEY=%d    \r\n",PS2_KEY);
		delay_ms(10);
	}	 
}



